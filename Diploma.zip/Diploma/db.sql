create table Themes (
	ID numeric(10, 0) not null,
	Title varchar(50) not null,
	Desctiption varchar(3000) not null
)
insert into Themes values (1, 'Простой оператор SELECT', 'Оператор SELECT осуществляет выборку из базы данных и имеет наиболее сложную структуру среди всех операторов языка SQL. Практически любой пользователь баз данных в состоянии написать простейший оператор SELECT типа 
SELECT * FROM Cars
который осуществляет выборку всех записей из объекта БД табличного типа с именем РС. При этом столбцы и строки результирующего набора не упорядочены. Чтобы упорядочить поля результирующего набора, их следует перечислить через запятую в нужном порядке после слова SELECT:
SELECT ID, MarkID, Name 
FROM Cars
Вертикальную проекцию таблицы РС можно получить, если перечислить только необходимые поля.
SELECT Name 
FROM Cars
Следует отметить, что вертикальная выборка может содержать дубликаты строк в том случае, если она не содержит потенциального ключа, однозначно определяющего запись. В таблице РС потенциальным ключом является поле code. Поскольку это поле отсутствует в запросе, в приведенном выше результирующем наборе имеются дубликаты строк (например, строки 1 и 3). Если требуется получить только уникальные строки (скажем, нас интересуют только различные комбинации скорости процессора и объема памяти, а не характеристики всех имеющихся компьютеров), то можно использовать ключевое слово DISTINCT:
SELECT DISTINCT MarkID 
FROM Cars') 


create table Tasks (
	ID numeric(10, 0),
	ThemeID numeric(10, 0),
	Description varchar(3000) not null
)
insert into Tasks values (1, 1, 'Выведите все записи из таблицы Marks', 'select * from Marks')
insert into Tasks values (2, 1, 'Выведите все записи из таблицы Cars, изключив колонки ID и MarkID из выборки', 'select Name from Cars')
insert into Tasks values (3, 1, 'Выведите все уникальные MarkID из таблицы Cars', 'select distinct MarkID from Cars')

create table Marks (
	ID numeric(10, 0),
	Name varchar(50) not null
)
insert into Marks values (1, 'BMW')
insert into Marks values (2, 'Mercedes')
insert into Marks values (3, 'Volga')


create table Cars (
	ID numeric(10, 0) not null,
	MarkID numeric(10, 0) not null,
	Name varchar(50) not null
)
insert into Cars values (1, 1, 'X1')
insert into Cars values (2, 1, 'X2')
insert into Cars values (3, 1, 'X3')
insert into Cars values (4, 2, 'GLS')
insert into Cars values (5, 2, 'GLC')
insert into Cars values (6, 2, 'CLA')
insert into Cars values (7, 3, '21')
insert into Cars values (8, 3, '24')


create table Themes (
	ID numeric(10, 0) not null,
	Title varchar(50) not null,
	Desctiption varchar(3000) not null
)
