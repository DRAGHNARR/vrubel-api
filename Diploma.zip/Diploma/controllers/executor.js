const { connection } = require("./connection");

async function extract(req, res, next) {
    taskSelect = `
        select t2.Title, t2.Description as ThemeDescription, t1.Description as TaskDescription
        from Tasks t1
        inner join Themes t2
        on t1.ThemeID = t2.ID
        where t1.ID = ${req.params.task}
    `

    try {
        task = await connection.query(taskSelect)
        res.send(task.rows);
    } catch (error) {
        console.error(error)
    }
}

async function execute(req, res, next) {
    taskSelect = `
        select TargetSQL
        from Tasks
        where ID = ${req.params.task}
    `

    taskSql = (await connection.query(taskSelect)).rows[0].targetsql
    
    const { select } = req.body;

    resultSql = `
        (${taskSql}
        except
        ${select})
        union all
        (${select}
        except
        ${taskSql})
    `

    answer = connection.query(resultSql).then(data => {
        const answer = {}
        answer["unexpected"] = data.rows
        answer["error"] = null

        try {
            res.send(answer);
        } catch (error) {
            console.error(error)
        }
    })
    .catch(err => {
        const answer = {}
        answer["unexpected"] = []
        answer["error"] = err

        try {
            res.send(answer);
        } catch (error) {
            console.error(error)
        }
    })
}
  
module.exports.execute = execute;
module.exports.extract = extract;