const { connection } = require("./connection");

async function extract(req, res, next) {
    taskSelect = `
        select title, text
        from tasks
        where id = ${req.params.task}
    `

    try {
        task = await connection.query(taskSelect)
        res.send(task.rows);
    } catch (error) {
        console.error(error)
    }
}

async function execute(req, res, next) {
    taskSelect = `
        select sqlResult
        from tasks
        where id = ${req.params.task}
    `

    taskSql = (await connection.query(taskSelect)).rows[0].sqlresult
    
    const { select } = req.body;

    resultSql = `
        ${taskSql}
        except
        ${select}
    `

    console.log(resultSql)

    answer = (await connection.query(resultSql)).rows
    
    console.log(answer)

    try {
        res.send(answer);
    } catch (error) {
        console.error(error)
    }
}
  
module.exports.execute = execute;
module.exports.extract = extract;