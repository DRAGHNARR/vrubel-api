const { Pool } = require('pg')

module.exports.connection = new Pool({
  user: 'postgres',
  database: 'Diploma',
  password: 'burninHELL111!',
  port: 5432,
  host: 'localhost',
});