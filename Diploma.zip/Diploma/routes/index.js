const router = require('express').Router();
const processes = require('./processes');

router.use('/tasks', processes);
/* router.use(auth);*/

module.exports = router;