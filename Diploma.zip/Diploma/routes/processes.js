const router = require('express').Router();
const { celebrate, Joi } = require('celebrate');
const validator = require('validator');
const { execute, extract } = require('../controllers/executor');


router.get('/:task', extract);

router.post('/:task', celebrate({
  body: Joi.object().keys({
    select: Joi.string().required(),
  }).unknown(true),
}), execute);

module.exports = router;